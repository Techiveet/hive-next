-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: hive
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `_prisma_migrations`
--

DROP TABLE IF EXISTS `_prisma_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `_prisma_migrations` (
  `id` varchar(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `checksum` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `finished_at` datetime(3) DEFAULT NULL,
  `migration_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `logs` text COLLATE utf8mb4_unicode_ci,
  `rolled_back_at` datetime(3) DEFAULT NULL,
  `started_at` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `applied_steps_count` int unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `_prisma_migrations`
--

LOCK TABLES `_prisma_migrations` WRITE;
/*!40000 ALTER TABLE `_prisma_migrations` DISABLE KEYS */;
INSERT INTO `_prisma_migrations` VALUES ('d33fff12-3eb3-4766-a4af-6b360bc71338','1a10ce2ed429646cc5479c95c60015257a36f191f1fbdeae25e93d4777a2bf2a','2025-12-04 09:54:12.856','20251204095358_init',NULL,NULL,'2025-12-04 09:54:09.052',1);
/*!40000 ALTER TABLE `_prisma_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `account`
--

DROP TABLE IF EXISTS `account`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `account` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accountId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `providerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `accessToken` text COLLATE utf8mb4_unicode_ci,
  `refreshToken` text COLLATE utf8mb4_unicode_ci,
  `idToken` text COLLATE utf8mb4_unicode_ci,
  `accessTokenExpiresAt` datetime(3) DEFAULT NULL,
  `refreshTokenExpiresAt` datetime(3) DEFAULT NULL,
  `scope` text COLLATE utf8mb4_unicode_ci,
  `password` text COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `account_providerId_accountId_key` (`providerId`,`accountId`),
  KEY `account_userId_idx` (`userId`),
  CONSTRAINT `account_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `account`
--

LOCK TABLES `account` WRITE;
/*!40000 ALTER TABLE `account` DISABLE KEYS */;
INSERT INTO `account` VALUES ('nZmWkrynQtYBlv1Z85oSXxRxEVVafnbk','13pUBdBAasoQLOz7EUY2AJVeC65LsyLy','credential','13pUBdBAasoQLOz7EUY2AJVeC65LsyLy',NULL,NULL,NULL,NULL,NULL,NULL,'$2b$10$8tBkhUh8KBMrPeIrq6zvPeFpPtznT/a45ku29i.zNsLEU3pkA2.IS','2025-12-04 09:54:14.235','2025-12-04 09:54:14.235'),('RBROgX1v849o2JQ40aZXFhKyj7ja39cA','T4FiBECOVmx7mXyCGgUlKAOEwz1O3YT9','credential','T4FiBECOVmx7mXyCGgUlKAOEwz1O3YT9',NULL,NULL,NULL,NULL,NULL,NULL,'$2b$10$08V8eNWI3twXJ1186RBJWuR.W6T339EZiwuenWSi.SmOWROORYPa.','2025-12-04 09:54:14.502','2025-12-04 09:54:14.502'),('VyDuYSZ7UHC42iNtvEXfGIPSwOFcTfQr','H6zaiP7K2GNLwOGy3eJVhVva0QbTJTj0','credential','H6zaiP7K2GNLwOGy3eJVhVva0QbTJTj0',NULL,NULL,NULL,NULL,NULL,NULL,'$2b$10$CFaTCXZhjT62R0XTvVYVUefEJfIxEZkn4aOx1zjmdneXm1T6SK/ve','2025-12-04 09:54:14.326','2025-12-04 09:54:14.326'),('xFcCOE5sAPcs18EQaapwzUUc90POxQfB','MxY8fncQDYjo0V4nCvGsnmYZdGmCm71D','credential','MxY8fncQDYjo0V4nCvGsnmYZdGmCm71D',NULL,NULL,NULL,NULL,NULL,NULL,'$2b$10$.pRegTB7SqQjZl7vKG7U/e2HVaGLNGP8zUu6crg7AJfJVz3bOiy/6','2025-12-04 09:54:14.417','2025-12-04 09:54:14.417');
/*!40000 ALTER TABLE `account` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `appsettings`
--

DROP TABLE IF EXISTS `appsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `appsettings` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `timezone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'UTC',
  `locale` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `dateFormat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'yyyy-MM-dd',
  `timeFormat` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'HH:mm',
  `weekStartsOn` int NOT NULL DEFAULT '1',
  `defaultTheme` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'system',
  `allowUserThemeOverride` tinyint(1) NOT NULL DEFAULT '1',
  `enforceTwoFactor` tinyint(1) NOT NULL DEFAULT '0',
  `sessionTimeout` int NOT NULL DEFAULT '30',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `AppSettings_tenantId_key` (`tenantId`),
  CONSTRAINT `AppSettings_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `appsettings`
--

LOCK TABLES `appsettings` WRITE;
/*!40000 ALTER TABLE `appsettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `appsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backuphistory`
--

DROP TABLE IF EXISTS `backuphistory`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backuphistory` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `filename` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `path` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` bigint NOT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  KEY `BackupHistory_tenantId_idx` (`tenantId`),
  CONSTRAINT `BackupHistory_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backuphistory`
--

LOCK TABLES `backuphistory` WRITE;
/*!40000 ALTER TABLE `backuphistory` DISABLE KEYS */;
/*!40000 ALTER TABLE `backuphistory` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `backupsettings`
--

DROP TABLE IF EXISTS `backupsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `backupsettings` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enabled` tinyint(1) NOT NULL DEFAULT '0',
  `frequency` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'DAILY',
  `time` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '00:00',
  `retention` int NOT NULL DEFAULT '7',
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BackupSettings_tenantId_key` (`tenantId`),
  CONSTRAINT `BackupSettings_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `backupsettings`
--

LOCK TABLES `backupsettings` WRITE;
/*!40000 ALTER TABLE `backupsettings` DISABLE KEYS */;
INSERT INTO `backupsettings` VALUES ('cmir9mahx0003ti80rxctwlyh','cmir9e4570002tilwxn60svpp',1,'DAILY','13:18',7,'2025-12-04 10:00:35.494','2025-12-04 10:17:35.455');
/*!40000 ALTER TABLE `backupsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `brandsettings`
--

DROP TABLE IF EXISTS `brandsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `brandsettings` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `titleText` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Hive',
  `footerText` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Powered by Hive',
  `logoLightUrl` longtext COLLATE utf8mb4_unicode_ci,
  `logoDarkUrl` longtext COLLATE utf8mb4_unicode_ci,
  `faviconUrl` longtext COLLATE utf8mb4_unicode_ci,
  `sidebarIconUrl` longtext COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `BrandSettings_tenantId_key` (`tenantId`),
  CONSTRAINT `BrandSettings_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `brandsettings`
--

LOCK TABLES `brandsettings` WRITE;
/*!40000 ALTER TABLE `brandsettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `brandsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companysettings`
--

DROP TABLE IF EXISTS `companysettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companysettings` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `companyName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `legalName` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `phone` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressLine1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `addressLine2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `postalCode` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `taxId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `registrationNumber` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `CompanySettings_tenantId_key` (`tenantId`),
  CONSTRAINT `CompanySettings_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companysettings`
--

LOCK TABLES `companysettings` WRITE;
/*!40000 ALTER TABLE `companysettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `companysettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `emailsettings`
--

DROP TABLE IF EXISTS `emailsettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `emailsettings` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `provider` enum('RESEND','SMTP') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'RESEND',
  `fromName` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fromEmail` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `replyToEmail` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtpHost` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtpPort` int DEFAULT NULL,
  `smtpUser` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `smtpSecurity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `EmailSettings_tenantId_key` (`tenantId`),
  CONSTRAINT `EmailSettings_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `emailsettings`
--

LOCK TABLES `emailsettings` WRITE;
/*!40000 ALTER TABLE `emailsettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `emailsettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `file`
--

DROP TABLE IF EXISTS `file`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `file` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `size` int NOT NULL,
  `mimeType` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `url` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `folderId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ownerId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `isFavorite` tinyint(1) NOT NULL DEFAULT '0',
  `deletedAt` datetime(3) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `File_tenantId_idx` (`tenantId`),
  KEY `File_folderId_fkey` (`folderId`),
  KEY `File_ownerId_fkey` (`ownerId`),
  CONSTRAINT `File_folderId_fkey` FOREIGN KEY (`folderId`) REFERENCES `folder` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `File_ownerId_fkey` FOREIGN KEY (`ownerId`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `File_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `file`
--

LOCK TABLES `file` WRITE;
/*!40000 ALTER TABLE `file` DISABLE KEYS */;
/*!40000 ALTER TABLE `file` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `filemanagersettings`
--

DROP TABLE IF EXISTS `filemanagersettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `filemanagersettings` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `maxFileSizeMb` int NOT NULL DEFAULT '50',
  `allowedExtensions` json NOT NULL,
  `autoEmptyRecycleBinDays` int NOT NULL DEFAULT '30',
  `requireDeleteConfirmation` tinyint(1) NOT NULL DEFAULT '1',
  `allowPublicSharing` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `FileManagerSettings_tenantId_key` (`tenantId`),
  CONSTRAINT `FileManagerSettings_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `filemanagersettings`
--

LOCK TABLES `filemanagersettings` WRITE;
/*!40000 ALTER TABLE `filemanagersettings` DISABLE KEYS */;
/*!40000 ALTER TABLE `filemanagersettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `folder`
--

DROP TABLE IF EXISTS `folder`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `folder` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parentId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdById` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `Folder_tenantId_idx` (`tenantId`),
  KEY `Folder_parentId_fkey` (`parentId`),
  KEY `Folder_createdById_fkey` (`createdById`),
  CONSTRAINT `Folder_createdById_fkey` FOREIGN KEY (`createdById`) REFERENCES `user` (`id`) ON DELETE RESTRICT ON UPDATE CASCADE,
  CONSTRAINT `Folder_parentId_fkey` FOREIGN KEY (`parentId`) REFERENCES `folder` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `Folder_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `folder`
--

LOCK TABLES `folder` WRITE;
/*!40000 ALTER TABLE `folder` DISABLE KEYS */;
/*!40000 ALTER TABLE `folder` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `language`
--

DROP TABLE IF EXISTS `language`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `language` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isDefault` tinyint(1) NOT NULL DEFAULT '0',
  `isEnabled` tinyint(1) NOT NULL DEFAULT '1',
  `translations` json NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Language_tenantId_code_key` (`tenantId`,`code`),
  CONSTRAINT `Language_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `language`
--

LOCK TABLES `language` WRITE;
/*!40000 ALTER TABLE `language` DISABLE KEYS */;
/*!40000 ALTER TABLE `language` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `password_setup_token`
--

DROP TABLE IF EXISTS `password_setup_token`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_setup_token` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiresAt` datetime(3) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  PRIMARY KEY (`id`),
  UNIQUE KEY `password_setup_token_token_key` (`token`),
  KEY `password_setup_token_userId_idx` (`userId`),
  CONSTRAINT `password_setup_token_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_setup_token`
--

LOCK TABLES `password_setup_token` WRITE;
/*!40000 ALTER TABLE `password_setup_token` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_setup_token` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Permission_tenantId_key_key` (`tenantId`,`key`),
  CONSTRAINT `Permission_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=131 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES (1,'dashboard.view','View Dashboard',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(2,'manage_tenants','Manage Tenants',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(3,'manage_settings','Manage Settings',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(4,'manage_billing','Manage Billing & Subscriptions',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(5,'view_audit_logs','View Audit Logs',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(6,'view_security','View Security Area',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(7,'manage_security','Manage Security (Users/Roles)',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(8,'users.view','View Users',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(9,'users.create','Create Users',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(10,'users.update','Update Users',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(11,'users.delete','Delete Users',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(12,'roles.view','View Roles',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(13,'roles.create','Create Roles',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(14,'roles.update','Update Roles',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(15,'roles.delete','Delete Roles',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(16,'permissions.view','View Permissions',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(17,'permissions.create','Create Permissions',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(18,'permissions.update','Update Permissions',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(19,'permissions.delete','Delete Permissions',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(20,'manage_users','Manage Users',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(21,'manage_roles','Manage Roles & Permissions',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(22,'files.view','View Files',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(23,'files.upload','Upload Files',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(24,'files.update','Rename / Move Files',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(25,'files.delete','Delete Files',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(26,'folders.view','View Folders',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(27,'folders.create','Create Folders',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(28,'folders.update','Rename / Move Folders',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(29,'folders.delete','Delete Folders',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(30,'manage_files','Manage Files & Folders',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(31,'manage_storage_settings','Manage Storage Settings',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(32,'settings.brand.view','View Brand Settings',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(33,'settings.brand.update','Update Brand Settings',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(34,'settings.company.view','View Company Settings',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(35,'settings.company.update','Update Company Settings',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(36,'settings.email.view','View Email Settings',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(37,'settings.email.update','Update Email Settings',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(38,'settings.notifications.view','View Notification Settings',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(39,'settings.notifications.update','Update Notification Settings',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(40,'settings.localization.view','View Localization / Languages',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(41,'settings.localization.update','Manage Localization / Languages',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(42,'departments.view','View Departments',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(43,'departments.create','Create Departments',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(44,'departments.update','Update Departments',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(45,'departments.delete','Delete Departments',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(46,'inventory.view','View Inventory Overview',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(47,'inventory.manage','Manage Inventory',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(48,'products.view','View Goods / Products',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(49,'products.create','Create Goods / Products',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(50,'products.update','Update Goods / Products',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(51,'products.delete','Delete Goods / Products',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(52,'products.export','Export Goods / Products',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(53,'products.print','Print Goods / Products',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(54,'product_categories.view','View Product Categories',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(55,'product_categories.create','Create Product Categories',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(56,'product_categories.update','Update Product Categories',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(57,'product_categories.delete','Delete Product Categories',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(58,'units.view','View Units of Measure',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(59,'units.create','Create Units of Measure',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(60,'units.update','Update Units of Measure',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(61,'units.delete','Delete Units of Measure',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(62,'shelves.view','View Shelves / Locations',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(63,'shelves.create','Create Shelves / Locations',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(64,'shelves.update','Update Shelves / Locations',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(65,'shelves.delete','Delete Shelves / Locations',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(66,'stock_adjustments.view','View Stock Adjustments',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(67,'stock_adjustments.create','Create Stock Adjustments',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(68,'stock_adjustments.update','Update Stock Adjustments',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(69,'stock_adjustments.delete','Delete Stock Adjustments',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(70,'suppliers.view','View Suppliers',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(71,'suppliers.create','Create Suppliers',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(72,'suppliers.update','Update Suppliers',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(73,'suppliers.delete','Delete Suppliers',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(74,'vendors.view','View Vendors',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(75,'vendors.create','Create Vendors',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(76,'vendors.update','Update Vendors',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(77,'vendors.delete','Delete Vendors',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(78,'vendor_opening_balances.view','View Vendor Opening Balances',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(79,'vendor_opening_balances.create','Create Vendor Opening Balances',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(80,'vendor_opening_balances.update','Update Vendor Opening Balances',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(81,'vendor_opening_balances.delete','Delete Vendor Opening Balances',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(82,'purchase_requests.view','View Purchase Requests',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(83,'purchase_requests.create','Create Purchase Requests',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(84,'purchase_requests.update','Update Purchase Requests',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(85,'purchase_requests.delete','Delete Purchase Requests',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(86,'purchase_requests.approve','Approve Purchase Requests',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(87,'purchase_requests.export','Export Purchase Requests',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(88,'purchase_requests.print','Print Purchase Requests',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(89,'purchase_orders.view','View Purchase Orders',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(90,'purchase_orders.create','Create Purchase Orders',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(91,'purchase_orders.update','Update Purchase Orders',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(92,'purchase_orders.delete','Delete Purchase Orders',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(93,'purchase_orders.approve','Approve Purchase Orders',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(94,'purchase_orders.export','Export Purchase Orders',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(95,'purchase_orders.print','Print Purchase Orders',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(96,'purchase_approvals.view','View Purchase Approvals',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(97,'purchase_approvals.approve','Approve / Reject Purchase Requests',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(98,'transfers.view','View Inventory Transfers',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(99,'transfers.create','Create Inventory Transfers',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(100,'transfers.update','Update Inventory Transfers',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(101,'transfers.delete','Delete Inventory Transfers',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(102,'transfers.approve','Approve Inventory Transfers',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(103,'goods_receiving.view','View Goods Receiving Notes',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(104,'goods_receiving.create','Create Goods Receiving Notes',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(105,'goods_receiving.update','Update Goods Receiving Notes',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(106,'goods_receiving.delete','Delete Goods Receiving Notes',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(107,'goods_receiving.approve','Approve / Sign Goods Receiving Notes',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(108,'goods_receiving.print','Print Goods Receiving Notes',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(109,'invoices.view','View Invoices',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(110,'invoices.create','Create Invoices',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(111,'invoices.update','Update Invoices',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(112,'invoices.delete','Delete Invoices',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(113,'invoices.approve','Approve Invoices',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(114,'invoices.print','Print Invoices',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(115,'invoices.export','Export Invoices',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(116,'payments.view','View Payments',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(117,'payments.create','Create Payments',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(118,'payments.update','Update Payments',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(119,'payments.delete','Delete Payments',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(120,'finance_reports.view','View Finance Reports',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(121,'notifications.view','View Notifications',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(122,'notifications.manage','Manage Notification Rules',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(123,'export.csv','Export to CSV',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(124,'export.excel','Export to Excel',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(125,'export.pdf','Export to PDF',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(126,'print.view','Use Print Views',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(127,'plans.view','View Subscription Plans',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(128,'plans.manage','Manage Subscription Plans',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(129,'subscriptions.view','View Subscriptions',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995'),(130,'subscriptions.manage','Manage Subscriptions',NULL,'2025-12-04 09:54:13.995','2025-12-04 09:54:13.995');
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scope` enum('CENTRAL','TENANT') COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `Role_tenantId_key_key` (`tenantId`,`key`),
  CONSTRAINT `Role_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'central_superadmin','Central Super Administrator','CENTRAL',NULL,'2025-12-04 09:54:14.025','2025-12-04 09:54:14.025'),(2,'tenant_superadmin','Tenant Super Administrator','TENANT','cmir9e4570002tilwxn60svpp','2025-12-04 09:54:14.033','2025-12-04 09:54:14.033'),(3,'tenant_admin','Tenant Administrator','TENANT','cmir9e4570002tilwxn60svpp','2025-12-04 09:54:14.042','2025-12-04 09:54:14.042'),(4,'tenant_member','Tenant Member','TENANT','cmir9e4570002tilwxn60svpp','2025-12-04 09:54:14.049','2025-12-04 09:54:14.049'),(5,'tenant_superadmin','Tenant Super Administrator','TENANT','cmir9e4560000tilwllod5nf1','2025-12-04 09:54:14.057','2025-12-04 09:54:14.057'),(6,'tenant_admin','Tenant Administrator','TENANT','cmir9e4560000tilwllod5nf1','2025-12-04 09:54:14.066','2025-12-04 09:54:14.066'),(7,'tenant_member','Tenant Member','TENANT','cmir9e4560000tilwllod5nf1','2025-12-04 09:54:14.073','2025-12-04 09:54:14.073'),(8,'tenant_superadmin','Tenant Super Administrator','TENANT','cmir9e4570001tilwlivnxadz','2025-12-04 09:54:14.080','2025-12-04 09:54:14.080'),(9,'tenant_admin','Tenant Administrator','TENANT','cmir9e4570001tilwlivnxadz','2025-12-04 09:54:14.086','2025-12-04 09:54:14.086'),(10,'tenant_member','Tenant Member','TENANT','cmir9e4570001tilwlivnxadz','2025-12-04 09:54:14.092','2025-12-04 09:54:14.092');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rolepermission`
--

DROP TABLE IF EXISTS `rolepermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rolepermission` (
  `roleId` int NOT NULL,
  `permissionId` int NOT NULL,
  PRIMARY KEY (`roleId`,`permissionId`),
  KEY `RolePermission_permissionId_fkey` (`permissionId`),
  CONSTRAINT `RolePermission_permissionId_fkey` FOREIGN KEY (`permissionId`) REFERENCES `permission` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `RolePermission_roleId_fkey` FOREIGN KEY (`roleId`) REFERENCES `role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rolepermission`
--

LOCK TABLES `rolepermission` WRITE;
/*!40000 ALTER TABLE `rolepermission` DISABLE KEYS */;
INSERT INTO `rolepermission` VALUES (1,1),(2,1),(3,1),(5,1),(6,1),(8,1),(9,1),(1,2),(1,3),(2,3),(3,3),(5,3),(6,3),(8,3),(9,3),(1,4),(2,4),(3,4),(5,4),(6,4),(8,4),(9,4),(1,5),(2,5),(3,5),(5,5),(6,5),(8,5),(9,5),(1,6),(2,6),(3,6),(5,6),(6,6),(8,6),(9,6),(1,7),(2,7),(3,7),(5,7),(6,7),(8,7),(9,7),(1,8),(2,8),(3,8),(5,8),(6,8),(8,8),(9,8),(1,9),(2,9),(3,9),(5,9),(6,9),(8,9),(9,9),(1,10),(2,10),(3,10),(5,10),(6,10),(8,10),(9,10),(1,11),(2,11),(3,11),(5,11),(6,11),(8,11),(9,11),(1,12),(2,12),(3,12),(5,12),(6,12),(8,12),(9,12),(1,13),(2,13),(3,13),(5,13),(6,13),(8,13),(9,13),(1,14),(2,14),(3,14),(5,14),(6,14),(8,14),(9,14),(1,15),(2,15),(3,15),(5,15),(6,15),(8,15),(9,15),(1,16),(2,16),(3,16),(5,16),(6,16),(8,16),(9,16),(1,17),(2,17),(3,17),(5,17),(6,17),(8,17),(9,17),(1,18),(2,18),(3,18),(5,18),(6,18),(8,18),(9,18),(1,19),(2,19),(3,19),(5,19),(6,19),(8,19),(9,19),(1,20),(2,20),(3,20),(5,20),(6,20),(8,20),(9,20),(1,21),(2,21),(3,21),(5,21),(6,21),(8,21),(9,21),(1,22),(2,22),(3,22),(4,22),(5,22),(6,22),(7,22),(8,22),(9,22),(10,22),(1,23),(2,23),(3,23),(4,23),(5,23),(6,23),(7,23),(8,23),(9,23),(10,23),(1,24),(2,24),(3,24),(5,24),(6,24),(8,24),(9,24),(1,25),(2,25),(3,25),(5,25),(6,25),(8,25),(9,25),(1,26),(2,26),(3,26),(5,26),(6,26),(8,26),(9,26),(1,27),(2,27),(3,27),(5,27),(6,27),(8,27),(9,27),(1,28),(2,28),(3,28),(5,28),(6,28),(8,28),(9,28),(1,29),(2,29),(3,29),(5,29),(6,29),(8,29),(9,29),(1,30),(2,30),(3,30),(4,30),(5,30),(6,30),(7,30),(8,30),(9,30),(10,30),(1,31),(2,31),(3,31),(5,31),(6,31),(8,31),(9,31),(1,32),(2,32),(3,32),(5,32),(6,32),(8,32),(9,32),(1,33),(2,33),(3,33),(5,33),(6,33),(8,33),(9,33),(1,34),(2,34),(3,34),(5,34),(6,34),(8,34),(9,34),(1,35),(2,35),(3,35),(5,35),(6,35),(8,35),(9,35),(1,36),(2,36),(3,36),(5,36),(6,36),(8,36),(9,36),(1,37),(2,37),(3,37),(5,37),(6,37),(8,37),(9,37),(1,38),(2,38),(3,38),(5,38),(6,38),(8,38),(9,38),(1,39),(2,39),(3,39),(5,39),(6,39),(8,39),(9,39),(1,40),(2,40),(3,40),(5,40),(6,40),(8,40),(9,40),(1,41),(2,41),(3,41),(5,41),(6,41),(8,41),(9,41),(1,42),(2,42),(3,42),(5,42),(6,42),(8,42),(9,42),(1,43),(2,43),(3,43),(5,43),(6,43),(8,43),(9,43),(1,44),(2,44),(3,44),(5,44),(6,44),(8,44),(9,44),(1,45),(2,45),(3,45),(5,45),(6,45),(8,45),(9,45),(1,46),(2,46),(3,46),(5,46),(6,46),(8,46),(9,46),(1,47),(2,47),(3,47),(5,47),(6,47),(8,47),(9,47),(1,48),(2,48),(3,48),(5,48),(6,48),(8,48),(9,48),(1,49),(2,49),(3,49),(5,49),(6,49),(8,49),(9,49),(1,50),(2,50),(3,50),(5,50),(6,50),(8,50),(9,50),(1,51),(2,51),(3,51),(5,51),(6,51),(8,51),(9,51),(1,52),(2,52),(3,52),(5,52),(6,52),(8,52),(9,52),(1,53),(2,53),(3,53),(5,53),(6,53),(8,53),(9,53),(1,54),(2,54),(3,54),(5,54),(6,54),(8,54),(9,54),(1,55),(2,55),(3,55),(5,55),(6,55),(8,55),(9,55),(1,56),(2,56),(3,56),(5,56),(6,56),(8,56),(9,56),(1,57),(2,57),(3,57),(5,57),(6,57),(8,57),(9,57),(1,58),(2,58),(3,58),(5,58),(6,58),(8,58),(9,58),(1,59),(2,59),(3,59),(5,59),(6,59),(8,59),(9,59),(1,60),(2,60),(3,60),(5,60),(6,60),(8,60),(9,60),(1,61),(2,61),(3,61),(5,61),(6,61),(8,61),(9,61),(1,62),(2,62),(3,62),(5,62),(6,62),(8,62),(9,62),(1,63),(2,63),(3,63),(5,63),(6,63),(8,63),(9,63),(1,64),(2,64),(3,64),(5,64),(6,64),(8,64),(9,64),(1,65),(2,65),(3,65),(5,65),(6,65),(8,65),(9,65),(1,66),(2,66),(3,66),(5,66),(6,66),(8,66),(9,66),(1,67),(2,67),(3,67),(5,67),(6,67),(8,67),(9,67),(1,68),(2,68),(3,68),(5,68),(6,68),(8,68),(9,68),(1,69),(2,69),(3,69),(5,69),(6,69),(8,69),(9,69),(1,70),(2,70),(3,70),(5,70),(6,70),(8,70),(9,70),(1,71),(2,71),(3,71),(5,71),(6,71),(8,71),(9,71),(1,72),(2,72),(3,72),(5,72),(6,72),(8,72),(9,72),(1,73),(2,73),(3,73),(5,73),(6,73),(8,73),(9,73),(1,74),(2,74),(3,74),(5,74),(6,74),(8,74),(9,74),(1,75),(2,75),(3,75),(5,75),(6,75),(8,75),(9,75),(1,76),(2,76),(3,76),(5,76),(6,76),(8,76),(9,76),(1,77),(2,77),(3,77),(5,77),(6,77),(8,77),(9,77),(1,78),(2,78),(3,78),(5,78),(6,78),(8,78),(9,78),(1,79),(2,79),(3,79),(5,79),(6,79),(8,79),(9,79),(1,80),(2,80),(3,80),(5,80),(6,80),(8,80),(9,80),(1,81),(2,81),(3,81),(5,81),(6,81),(8,81),(9,81),(1,82),(2,82),(3,82),(5,82),(6,82),(8,82),(9,82),(1,83),(2,83),(3,83),(5,83),(6,83),(8,83),(9,83),(1,84),(2,84),(3,84),(5,84),(6,84),(8,84),(9,84),(1,85),(2,85),(3,85),(5,85),(6,85),(8,85),(9,85),(1,86),(2,86),(3,86),(5,86),(6,86),(8,86),(9,86),(1,87),(2,87),(3,87),(5,87),(6,87),(8,87),(9,87),(1,88),(2,88),(3,88),(5,88),(6,88),(8,88),(9,88),(1,89),(2,89),(3,89),(5,89),(6,89),(8,89),(9,89),(1,90),(2,90),(3,90),(5,90),(6,90),(8,90),(9,90),(1,91),(2,91),(3,91),(5,91),(6,91),(8,91),(9,91),(1,92),(2,92),(3,92),(5,92),(6,92),(8,92),(9,92),(1,93),(2,93),(3,93),(5,93),(6,93),(8,93),(9,93),(1,94),(2,94),(3,94),(5,94),(6,94),(8,94),(9,94),(1,95),(2,95),(3,95),(5,95),(6,95),(8,95),(9,95),(1,96),(2,96),(3,96),(5,96),(6,96),(8,96),(9,96),(1,97),(2,97),(3,97),(5,97),(6,97),(8,97),(9,97),(1,98),(2,98),(3,98),(5,98),(6,98),(8,98),(9,98),(1,99),(2,99),(3,99),(5,99),(6,99),(8,99),(9,99),(1,100),(2,100),(3,100),(5,100),(6,100),(8,100),(9,100),(1,101),(2,101),(3,101),(5,101),(6,101),(8,101),(9,101),(1,102),(2,102),(3,102),(5,102),(6,102),(8,102),(9,102),(1,103),(2,103),(3,103),(5,103),(6,103),(8,103),(9,103),(1,104),(2,104),(3,104),(5,104),(6,104),(8,104),(9,104),(1,105),(2,105),(3,105),(5,105),(6,105),(8,105),(9,105),(1,106),(2,106),(3,106),(5,106),(6,106),(8,106),(9,106),(1,107),(2,107),(3,107),(5,107),(6,107),(8,107),(9,107),(1,108),(2,108),(3,108),(5,108),(6,108),(8,108),(9,108),(1,109),(2,109),(3,109),(5,109),(6,109),(8,109),(9,109),(1,110),(2,110),(3,110),(5,110),(6,110),(8,110),(9,110),(1,111),(2,111),(3,111),(5,111),(6,111),(8,111),(9,111),(1,112),(2,112),(3,112),(5,112),(6,112),(8,112),(9,112),(1,113),(2,113),(3,113),(5,113),(6,113),(8,113),(9,113),(1,114),(2,114),(3,114),(5,114),(6,114),(8,114),(9,114),(1,115),(2,115),(3,115),(5,115),(6,115),(8,115),(9,115),(1,116),(2,116),(3,116),(5,116),(6,116),(8,116),(9,116),(1,117),(2,117),(3,117),(5,117),(6,117),(8,117),(9,117),(1,118),(2,118),(3,118),(5,118),(6,118),(8,118),(9,118),(1,119),(2,119),(3,119),(5,119),(6,119),(8,119),(9,119),(1,120),(2,120),(3,120),(5,120),(6,120),(8,120),(9,120),(1,121),(2,121),(3,121),(5,121),(6,121),(8,121),(9,121),(1,122),(2,122),(3,122),(5,122),(6,122),(8,122),(9,122),(1,123),(2,123),(3,123),(5,123),(6,123),(8,123),(9,123),(1,124),(2,124),(3,124),(5,124),(6,124),(8,124),(9,124),(1,125),(2,125),(3,125),(5,125),(6,125),(8,125),(9,125),(1,126),(2,126),(3,126),(5,126),(6,126),(8,126),(9,126),(1,127),(2,127),(3,127),(5,127),(6,127),(8,127),(9,127),(1,128),(2,128),(3,128),(5,128),(6,128),(8,128),(9,128),(1,129),(2,129),(3,129),(5,129),(6,129),(8,129),(9,129),(1,130),(2,130),(3,130),(5,130),(6,130),(8,130),(9,130);
/*!40000 ALTER TABLE `rolepermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `session`
--

DROP TABLE IF EXISTS `session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `session` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiresAt` datetime(3) NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `ipAddress` text COLLATE utf8mb4_unicode_ci,
  `userAgent` text COLLATE utf8mb4_unicode_ci,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `session_token_key` (`token`),
  KEY `session_userId_idx` (`userId`),
  CONSTRAINT `session_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `session`
--

LOCK TABLES `session` WRITE;
/*!40000 ALTER TABLE `session` DISABLE KEYS */;
INSERT INTO `session` VALUES ('2ZSVUwoLvGyH3z1AyuEmAiaAJl5tfQvp','2025-12-11 09:54:14.424','vgTj3Du6gannAz2cDEjPHix6EKcs93X2','2025-12-04 09:54:14.424','2025-12-04 09:54:14.424','','','MxY8fncQDYjo0V4nCvGsnmYZdGmCm71D'),('3bqtUEbkTvF2Ipb6CltpOdTVR5EhtbY7','2025-12-11 09:54:32.952','kHPpeYecFUPtZjGHplTH2p5RSr7qnIpm','2025-12-04 09:54:32.952','2025-12-04 09:54:32.952','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0','13pUBdBAasoQLOz7EUY2AJVeC65LsyLy'),('ikTwE4urDa8DjZgNHs8xpFHe8ufdKZNs','2025-12-11 09:54:14.242','7T7m282crVedr5sqnpV96lrslvsPir9u','2025-12-04 09:54:14.242','2025-12-04 09:54:14.242','','','13pUBdBAasoQLOz7EUY2AJVeC65LsyLy'),('Mp8vOON9ZArcc3mf4xnqVNF7GbSWKmpe','2025-12-11 09:54:14.332','B2YEM82Ftv0GopPzKZTLEwgMbDKdM7ye','2025-12-04 09:54:14.332','2025-12-04 09:54:14.332','','','H6zaiP7K2GNLwOGy3eJVhVva0QbTJTj0'),('qSeoiHfyGU3j90PjNUcr8hx8g0j7hs49','2025-12-11 09:54:14.509','6NuIb7GZNMt31SlbOlIsvfyOamJT4HyQ','2025-12-04 09:54:14.509','2025-12-04 09:54:14.509','','','T4FiBECOVmx7mXyCGgUlKAOEwz1O3YT9'),('ZOg6tvAbkRepfRLPvFhBGTvyGHUubBlk','2025-12-11 10:17:47.954','SfYfirG4xQRSRk4EXqH64i4jG0WciKNc','2025-12-04 10:17:47.954','2025-12-04 10:17:47.954','127.0.0.1','Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:145.0) Gecko/20100101 Firefox/145.0','H6zaiP7K2GNLwOGy3eJVhVva0QbTJTj0');
/*!40000 ALTER TABLE `session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenant`
--

DROP TABLE IF EXISTS `tenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenant` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `Tenant_slug_key` (`slug`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenant`
--

LOCK TABLES `tenant` WRITE;
/*!40000 ALTER TABLE `tenant` DISABLE KEYS */;
INSERT INTO `tenant` VALUES ('cmir9e4560000tilwllod5nf1','Acme Corp','acme-corp','2025-12-04 09:54:14.010','2025-12-04 09:54:14.010',1),('cmir9e4570001tilwlivnxadz','Beta Labs','beta-labs','2025-12-04 09:54:14.010','2025-12-04 09:54:14.010',1),('cmir9e4570002tilwxn60svpp','Central Hive','central-hive','2025-12-04 09:54:14.010','2025-12-04 09:54:14.010',1);
/*!40000 ALTER TABLE `tenant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `tenantdomain`
--

DROP TABLE IF EXISTS `tenantdomain`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `tenantdomain` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `domain` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `TenantDomain_tenantId_key` (`tenantId`),
  UNIQUE KEY `TenantDomain_domain_key` (`domain`),
  CONSTRAINT `TenantDomain_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tenantdomain`
--

LOCK TABLES `tenantdomain` WRITE;
/*!40000 ALTER TABLE `tenantdomain` DISABLE KEYS */;
INSERT INTO `tenantdomain` VALUES ('cmir9e48f0005tilwmlspm5y2','cmir9e4560000tilwllod5nf1','acme.localhost','2025-12-04 09:54:14.128','2025-12-04 09:54:14.128'),('cmir9e48f0006tilwyv2dnigg','cmir9e4570001tilwlivnxadz','beta.localhost','2025-12-04 09:54:14.128','2025-12-04 09:54:14.128'),('cmir9e48f0008tilwc58rvkcs','cmir9e4570002tilwxn60svpp','central.localhost','2025-12-04 09:54:14.128','2025-12-04 09:54:14.128');
/*!40000 ALTER TABLE `tenantdomain` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `name` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `emailVerified` tinyint(1) NOT NULL DEFAULT '0',
  `twoFactorEnabled` tinyint(1) NOT NULL DEFAULT '0',
  `image` longtext COLLATE utf8mb4_unicode_ci,
  `avatarUrl` longtext COLLATE utf8mb4_unicode_ci,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  `isActive` tinyint(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`),
  UNIQUE KEY `user_email_key` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES ('13pUBdBAasoQLOz7EUY2AJVeC65LsyLy','Central Superadmin','central.admin@hive.test',1,0,NULL,NULL,'2025-12-04 09:54:14.227','2025-12-04 09:54:14.253',1),('H6zaiP7K2GNLwOGy3eJVhVva0QbTJTj0','Acme Superadmin','acme.admin@hive.test',1,0,NULL,NULL,'2025-12-04 09:54:14.320','2025-12-04 09:54:14.341',1),('MxY8fncQDYjo0V4nCvGsnmYZdGmCm71D','Beta Labs Superadmin','beta.admin@hive.test',1,0,NULL,NULL,'2025-12-04 09:54:14.410','2025-12-04 09:54:14.433',1),('T4FiBECOVmx7mXyCGgUlKAOEwz1O3YT9','Central Hive Superadmin','central.hive.admin@hive.test',1,0,NULL,NULL,'2025-12-04 09:54:14.495','2025-12-04 09:54:14.518',1);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userrole`
--

DROP TABLE IF EXISTS `userrole`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userrole` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `roleId` int NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UserRole_userId_roleId_tenantId_key` (`userId`,`roleId`,`tenantId`),
  KEY `UserRole_roleId_fkey` (`roleId`),
  KEY `UserRole_tenantId_fkey` (`tenantId`),
  CONSTRAINT `UserRole_roleId_fkey` FOREIGN KEY (`roleId`) REFERENCES `role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `UserRole_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE SET NULL ON UPDATE CASCADE,
  CONSTRAINT `UserRole_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userrole`
--

LOCK TABLES `userrole` WRITE;
/*!40000 ALTER TABLE `userrole` DISABLE KEYS */;
INSERT INTO `userrole` VALUES ('cmir9e4jz000gtilwc8nu63ps','13pUBdBAasoQLOz7EUY2AJVeC65LsyLy',1,NULL),('cmir9e4k5000itilwbp03bncw','H6zaiP7K2GNLwOGy3eJVhVva0QbTJTj0',5,'cmir9e4560000tilwllod5nf1'),('cmir9e4kd000ktilwde0f7jzo','MxY8fncQDYjo0V4nCvGsnmYZdGmCm71D',8,'cmir9e4570001tilwlivnxadz'),('cmir9e4kk000mtilwc0nwi4lx','T4FiBECOVmx7mXyCGgUlKAOEwz1O3YT9',2,'cmir9e4570002tilwxn60svpp');
/*!40000 ALTER TABLE `userrole` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `usertenant`
--

DROP TABLE IF EXISTS `usertenant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `usertenant` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `userId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tenantId` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `isOwner` tinyint(1) NOT NULL DEFAULT '0',
  PRIMARY KEY (`id`),
  UNIQUE KEY `UserTenant_userId_tenantId_key` (`userId`,`tenantId`),
  KEY `UserTenant_tenantId_fkey` (`tenantId`),
  CONSTRAINT `UserTenant_tenantId_fkey` FOREIGN KEY (`tenantId`) REFERENCES `tenant` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `UserTenant_userId_fkey` FOREIGN KEY (`userId`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `usertenant`
--

LOCK TABLES `usertenant` WRITE;
/*!40000 ALTER TABLE `usertenant` DISABLE KEYS */;
INSERT INTO `usertenant` VALUES ('cmir9e4jf000atilwdt9z6ysi','H6zaiP7K2GNLwOGy3eJVhVva0QbTJTj0','cmir9e4560000tilwllod5nf1',1),('cmir9e4jm000ctilwat7hqvrn','MxY8fncQDYjo0V4nCvGsnmYZdGmCm71D','cmir9e4570001tilwlivnxadz',1),('cmir9e4jr000etilw00swvdxq','T4FiBECOVmx7mXyCGgUlKAOEwz1O3YT9','cmir9e4570002tilwxn60svpp',1);
/*!40000 ALTER TABLE `usertenant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `verification`
--

DROP TABLE IF EXISTS `verification`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `verification` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `identifier` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `expiresAt` datetime(3) NOT NULL,
  `createdAt` datetime(3) NOT NULL DEFAULT CURRENT_TIMESTAMP(3),
  `updatedAt` datetime(3) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `verification_identifier_idx` (`identifier`(191))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `verification`
--

LOCK TABLES `verification` WRITE;
/*!40000 ALTER TABLE `verification` DISABLE KEYS */;
/*!40000 ALTER TABLE `verification` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2025-12-04 13:18:42
